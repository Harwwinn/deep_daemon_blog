<?php 
define('BASE_URL', '/'); // Or just '/' if it's at the root
define('BASE_PATH', __DIR__ . '/..'); // The absolute server path to the project root
?>