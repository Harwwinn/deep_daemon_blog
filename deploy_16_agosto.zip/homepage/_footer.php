    </main>
    <footer class="bg-gray-900 text-gray-300">
        <div class="container mx-auto py-12 px-4 sm:px-6 lg:px-8">
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
                <!-- Columna About -->
                <div class="space-y-4">
                    <h3 class="text-xl font-bold text-white">Bark<span class="text-primary-500">Code</span></h3>
                    <p class="text-gray-400">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
                    <p><span class="font-semibold text-white">Correo:</span> info@metablog.net</p>
                    <p><span class="font-semibold text-white">Télefono:</span> +1 23 456 789</p>
                </div>
                <!-- Quick Links -->
                <div>
                    <h4 class="font-semibold text-white tracking-wider uppercase">Acceso rápido</h4>
                    <ul class="mt-4 space-y-2">
                        <li><a href="/blog_educativo_local/index.php" class="hover:text-primary-400">Inicio</a></li>
                        <li><a href="/blog_educativo_local/homepage/about.php" class="hover:text-primary-400">Sobre mí</a></li>
                        <li><a href="#" class="hover:text-primary-400">FAQ</a></li>
                        <li><a href="#" class="hover:text-primary-400">Contacto</a></li>
                    </ul>
                </div>
                <!-- Category -->
                <div>
                    <h4 class="font-semibold text-white tracking-wider uppercase">Categorías</h4>
                    <ul class="mt-4 space-y-2">
                        <li><a href="#" class="hover:text-primary-400">Tecnología</a></li>
                        <li><a href="#" class="hover:text-primary-400">Desarrollo web</a></li>
                        <li><a href="#" class="hover:text-primary-400">Noticias</a></li>
                        <li><a href="#" class="hover:text-primary-400">Tutoriales</a></li>
                    </ul>
                </div>
                
            </div>
            <div class="mt-8 pt-8 border-t border-gray-700 flex flex-col sm:flex-row justify-between items-center">
                <p class="text-gray-400">© <?php echo date('Y'); ?> BarkCode. Todos los derechos reservados.</p>
                <div class="flex space-x-4 mt-4 sm:mt-0">
                    <a href="#" class="hover:text-white">Términos de uso</a>
                    <a href="#" class="hover:text-white">Política de privacidad</a>
                    <a href="#" class="hover:text-white">Cookies</a>
                </div>
            </div>
        </div>
    </footer>
</body>
</html>